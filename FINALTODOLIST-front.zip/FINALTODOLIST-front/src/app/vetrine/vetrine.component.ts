import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vetrine',
  templateUrl: './vetrine.component.html',
  styleUrls: ['./vetrine.component.css']
})
export class VetrineComponent implements OnInit {

  title = "Todo List !";

  constructor() { }

  ngOnInit() {
  }

}
