export class Todo{

    constructor(    
        public _id?: String,
        public text?: String,
        public dateaj?:String,
        public completed?: String,
        public completedAt?: String,
        public _userId?: String){
    }
}